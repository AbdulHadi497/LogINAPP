package com.example.loginapp;

public @interface Generated {
}
